using System;
using UnityEngine;

[Serializable]
public class DSprite : DynamicLoadObject<Sprite>
{
}
