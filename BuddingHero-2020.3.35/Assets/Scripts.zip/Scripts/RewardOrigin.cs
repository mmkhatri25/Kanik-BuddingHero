using System;

public enum RewardOrigin
{
	Server,
	News,
	InGame
}
