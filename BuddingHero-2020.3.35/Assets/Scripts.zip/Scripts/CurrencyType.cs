using System;

public enum CurrencyType
{
	GOLD,
	SCRAP,
	MYTHSTONE,
	GEM,
	TOKEN,
	AEON,
	CANDY,
	TRINKET_BOX
}
