using System;

public enum RatingState
{
	NeverAsked,
	AskLater,
	PlayerRated,
	DontAskAgain
}
