using System;

public static class BuffTags
{
	public static int LENNY_HEAL = 1;

	public static int BABU_HEAL = 2;
}
