using System;

public enum AuthState
{
	INIT,
	WAIT_SERVER_RESP,
	COMPLETED_SUCCESS,
	COMPLETED_FAIL
}
