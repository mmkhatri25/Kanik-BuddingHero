using System;

public static class UnlockLevelsOld
{
	public static int HERO_VEXX = 9;

	public static int MERCHANT = 12;

	public static int TOKENS_00 = 13;

	public static int HERO_LENNY = 17;

	public static int CREDITS_00 = 21;

	public static int RUNE_CHARGE = 28;

	public static int PRESTIGE = 30;

	public static int HERO_SAM = 33;

	public static int MYTHSTONES_00 = 38;

	public static int MERCHANT_TAP = 42;

	public static int CREDITS_01 = 46;

	public static int RING_FIRE = 49;

	public static int SCRAPS_00 = 56;

	public static int COMPASS = 62;

	public static int MYTHSTONES_01 = 68;

	public static int HERO_V = 75;

	public static int SCRAPS_01 = 82;

	public static int MERCHANT_TIME_WARP = 90;

	public static int CREDITS_02 = 98;

	public static int HERO_WENDLE = 106;

	public static int MYTHSTONES_02 = 114;

	public static int RING_ICE = 122;

	public static int TOKENS_01 = 131;

	public static int HERO_LIA = 140;

	public static int SCRAPS_02 = 149;

	public static int RUNE_COOLER = 158;

	public static int MYTHSTONES_03 = 167;

	public static int RUNE_ICE_STORMER = 177;

	public static int CREDITS_03 = 187;

	public static int TRINKET_SLOT_00 = 192;

	public static int TRINKET_PACK_00 = 193;

	public static int TOKENS_02 = 197;

	public static int RUNE_ENERGY = 207;

	public static int TRINKET_PACK_01 = 212;

	public static int MYTHSTONES_04 = 218;

	public static int HERO_JIM = 224;

	public static int SCRAPS_03 = 229;

	public static int DAILY_QUEST = 235;

	public static int RUNE_IGNITION = 240;

	public static int MINE_SCRAPS = 246;

	public static int CREDITS_04 = 252;

	public static int RING_EARTH = 258;

	public static int MYTHSTONES_05 = 264;

	public static int TRINKET_SLOT_01 = 270;

	public static int TRINKET_PACK_02 = 273;

	public static int RUNE_ICE_RAGE = 276;

	public static int RUNE_WISHFUL = 282;

	public static int SCRAPS_04 = 288;

	public static int RUNE_THUNDER = 294;

	public static int MYTHICAL_SLOT_00 = 300;

	public static int CREDITS_05 = 306;

	public static int RUNE_SPIRITUAL = 312;

	public static int RUNE_FIRE_MAGMA = 318;

	public static int HERO_TAM = 324;

	public static int MYTHSTONES_06 = 330;

	public static int TRINKET_SLOT_02 = 336;

	public static int RUNE_SHARPNESS = 342;

	public static int TRINKET_PACK_03 = 348;

	public static int MYTHICAL_SLOT_01 = 354;

	public static int TOKENS_03 = 360;

	public static int TRINKET_PACK_04 = 366;

	public static int CREDITS_06 = 372;

	public static int MERCHANT_SHIELD = 378;

	public static int SKILL_POINTS_AUTO_DIST = 381;

	public static int TOKENS_04 = 385;

	public static int MYTHSTONES_07 = 391;

	public static int MINE_TOKEN = 395;

	public static int MYTHICAL_SLOT_02 = 400;

	public static int RUNE_STARFALL = 405;

	public static int CREDITS_07 = 410;

	public static int MYTHICAL_SLOT_03 = 416;

	public static int RUNE_RASH = 422;

	public static int SCRAPS_05 = 434;

	public static int HERO_REDROH = 440;

	public static int MERCHANT_GOLD = 446;

	public static int TOKENS_05 = 449;

	public static int TRINKET_SLOT_03 = 455;

	public static int MYTHICAL_SLOT_04 = 461;

	public static int MYTHSTONES_08 = 469;

	public static int CREDITS_08 = 477;

	public static int HERO_NANNA = 480;

	public static int MYTHICAL_SLOT_05 = 487;

	public static int SCRAPS_06 = 497;

	public static int TRINKET_DISASSEMBLE = 500;

	public static int MYTHICAL_SLOT_06 = 503;

	public static int RUNE_BLAZE = 509;

	public static int MYTHSTONES_09 = 515;

	public static int HERO_UNO = 518;

	public static int TRINKET_SLOT_04 = 521;

	public static int MYTHICAL_SLOT_07 = 527;

	public static int CREDITS_09 = 537;

	public static int MYTHICAL_SLOT_08 = 549;

	public static int TRINKET_SLOT_05 = 553;

	public static int MYTHICAL_SLOT_09 = 557;

	public static int MYTHSTONES_10 = 565;

	public static int MYTHICAL_SLOT_10 = 580;

	public static int TRINKET_SLOT_06 = 585;

	public static int MYTHSTONES_11 = 588;

	public static int MYTHICAL_SLOT_11 = 596;

	public static int SCRAPS_07 = 604;

	public static int MYTHSTONES_12 = 611;

	public static int MERCHANT_WAVE_CLEAR = 621;

	public static int TOKENS_06 = 624;

	public static int MYTHICAL_SLOT_12 = 630;

	public static int HERO_RON = 632;

	public static int RUNE_GLACIER = 636;

	public static int CREDITS_10 = 648;

	public static int MYTHICAL_SLOT_13 = 654;

	public static int MYTHSTONES_13 = 660;

	public static int MYTHICAL_SLOT_14 = 672;

	public static int SCRAPS_08 = 690;

	public static int TOKENS_07 = 705;

	public static int CREDITS_11 = 720;

	public static int MYTHICAL_SLOT_15 = 730;

	public static int MYTHSTONES_14 = 735;

	public static int SCRAPS_09 = 750;

	public static int TOKENS_08 = 765;

	public static int MYTHICAL_SLOT_16 = 775;

	public static int CREDITS_12 = 780;

	public static int MYTHSTONES_15 = 795;

	public static int SCRAPS_10 = 810;

	public static int MYTHICAL_SLOT_17 = 815;

	public static int TOKENS_09 = 825;

	public static int CREDITS_13 = 840;

	public static int MYTHSTONES_16 = 860;

	public static int TRINKET_SLOT_07 = 870;

	public static int TOKENS_10 = 880;

	public static int CREDITS_14 = 900;

	public static int TRINKET_PACK_05 = 905;

	public static int TRINKET_SLOT_08 = 910;

	public static int TOKENS_11 = 925;

	public static int MYTHSTONES_17 = 950;

	public static int SCRAPS_13 = 970;

	public static int TOKENS_12 = 990;

	public static int CREDITS_17 = 1000;

	public static int SCRAPS_12 = 1050;

	public static int CREDITS_15 = 1100;

	public static int CREDITS_16 = 1200;

	public static int MYTHICAL_SLOT_18 = 1250;
}
