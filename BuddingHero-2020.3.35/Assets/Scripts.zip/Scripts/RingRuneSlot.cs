using System;
using UnityEngine;
using UnityEngine.UI;

public class RingRuneSlot : MonoBehaviour
{
	public Image bgGlow;

	public Image line;
}
