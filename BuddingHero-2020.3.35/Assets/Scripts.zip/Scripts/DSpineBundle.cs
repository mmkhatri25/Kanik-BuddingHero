using System;

[Serializable]
public class DSpineBundle : DynamicLoadObject<SpineBundle>
{
}
