using System;

public class WeaponIds
{
	public const int IDA_DEFAULT = 100;

	public const int LENNY_DEFAULT = 101;

	public const int SHEELA_DEFAULT = 102;

	public const int BELLYLARF_ULTI = 103;

	public const int HILT_DEFAULT = 104;

	public const int BELLYLARF_DEFAULT = 105;

	public const int SHEELA_ULTI = 106;

	public const int LIA_ULTI = 107;

	public const int SAM_ULTI = 108;

	public const int LIA_DEFAULT = 109;

	public const int BOOMER_DEFAULT = 110;

	public const int DEREK_DEFAULT = 111;

	public const int SAM_DEFAULT = 112;

	public const int JIM_DEFAULT = 113;

	public const int TAM_DEFAULT = 114;

	public const int WARLOCK_DEFAULT = 115;

	public const int GOBLIN_DEFAULT = 116;

	public const int BABU_DEFAULT = 117;

	public const int BABU_MELEE = 118;

	public const int BABU_RANGE = 119;

	public const int DRUID_DEFAULT = 120;

	public const int DRUID_ULTI = 121;
}
