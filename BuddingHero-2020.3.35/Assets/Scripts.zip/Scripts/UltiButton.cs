using System;
using UnityEngine;

public class UltiButton : MonoBehaviour
{
	private void Start()
	{
	}

	private void Update()
	{
	}
}
