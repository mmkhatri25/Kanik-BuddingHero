using System;

namespace UIReborn
{
	public class WindowHub : UIWindowBase
	{
	}
}
