using System;
using UnityEngine;

public class Christmas : MonoBehaviour
{
	private void Start()
	{
	}

	private void Update()
	{
	}
}
