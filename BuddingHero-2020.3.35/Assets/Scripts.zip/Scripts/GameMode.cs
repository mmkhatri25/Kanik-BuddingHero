using System;

public enum GameMode
{
	STANDARD,
	SOLO,
	CRUSADE,
	RIFT
}
