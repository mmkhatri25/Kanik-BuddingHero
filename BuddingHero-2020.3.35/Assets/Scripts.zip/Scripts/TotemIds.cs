using System;

public static class TotemIds
{
	public const string EARTH = "totemEarth";

	public const string FIRE = "totemFire";

	public const string ICE = "totemIce";

	public const string LIGHTNING = "totemLightning";
}
