using System;

public static class MerchantItemIds
{
	public const string GOLD_PACK = "GOLD_PACK";

	public const string WARP_TIME = "WARP_TIME";

	public const string SHIELD = "SHIELD";

	public const string AUTO_TAP = "AUTO_TAP";

	public const string TRAINING_BOOK = "TRAINING_BOOK";

	public const string CLOCK = "CLOCK";

	public const string POWER_UP = "POWER_UP";

	public const string REFRESHER_ORB = "REFRESHER_ORB";

	public const string GOLD_BOOST = "GOLD_BOOST";

	public const string WAVE_CLEAR = "WAVE_CLEAR";

	public const string CHARM_CATALYST = "CHARM_CATALYST";

	public const string CHARM_VARIETY = "CHARM_VARIETY";

	public const string EMERGENCY_CHARM = "EMERGENCY_CHARM";

	public const string PICK_RANDOM_CHARMS = "PICK_RANDOM_CHARMS";

	public const string BLIZZARD = "BLIZZARD";

	public const string HOT_COCOA = "HOT_COCOA";

	public const string ORNAMENT_DROP = "ORNAMENT_DROP";
}
