using System;
using Simulation;

public class DamageLog
{
	public Damage damage;

	public UnitHealthy damaged;

	public Unit damager;
}
