using System;

public class NativeReviewRequest
{
	public static void RequestReview()
	{
	}
}
