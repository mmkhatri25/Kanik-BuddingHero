using System;
using UnityEngine.Playables;

[Serializable]
public class SpineSkeletonFlipBehaviour : PlayableBehaviour
{
	public bool flipX;

	public bool flipY;
}
