using System;

namespace Ui
{
	public delegate bool CommandCondition();
}
