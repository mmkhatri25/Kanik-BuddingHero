using System;
using UnityEngine;
using UnityEngine.UI;

namespace Ui
{
	public class PanelLocked : AahMonoBehaviour
	{
		public RectTransform rectTransform;

		public Text textGoalType;

		public Text textStage;

		public Image icon;
	}
}
