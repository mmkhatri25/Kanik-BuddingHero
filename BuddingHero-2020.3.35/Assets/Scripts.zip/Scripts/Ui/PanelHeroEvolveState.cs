using System;

namespace Ui
{
	public enum PanelHeroEvolveState
	{
		OPENING,
		OPENED,
		EVOLVE_ANIM,
		FADING_IN,
		EVOLVED,
		CLOSING,
		CLOSED
	}
}
