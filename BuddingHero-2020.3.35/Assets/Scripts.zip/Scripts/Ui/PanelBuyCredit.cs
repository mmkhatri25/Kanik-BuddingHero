using System;
using UnityEngine.UI;

namespace Ui
{
	public class PanelBuyCredit : AahMonoBehaviour
	{
		public Image imageIcon;

		public Text textUp;

		public Text textDown;

		public Image imageMore;

		public Text textMore;

		public GameButton buttonBuy;
	}
}
