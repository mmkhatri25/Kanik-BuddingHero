using System;
using UnityEngine.UI;

namespace Ui
{
	public class ShopItem : AahMonoBehaviour
	{
		public GameButton gameButton;

		public Image imageButton;

		public Text textUp;

		public Text textDown;

		public Image coinIcon;
	}
}
