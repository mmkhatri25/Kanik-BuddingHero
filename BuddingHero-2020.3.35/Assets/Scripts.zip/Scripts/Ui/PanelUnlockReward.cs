using System;
using UnityEngine.UI;

namespace Ui
{
	public class PanelUnlockReward : AahMonoBehaviour
	{
		public Text textHeader;

		public Image imageReward;

		public Text textReward;

		public GameButton gameButton;
	}
}
