using System;
using UnityEngine;
using UnityEngine.UI;

namespace Ui
{
	public class TrinketEffectSlot : MonoBehaviour
	{
		public GameButton buttonDiscard;

		public PanelTrinketEffect panelTrinket;

		public Text groupLabel;
	}
}
