using System;

namespace Ui
{
	public enum LootType
	{
		TOKENS,
		GEAR,
		SCRAPS,
		RUNE,
		CREDITS,
		TRINKET,
		TRINKET_BOX,
		SKINS,
		CANDIES
	}
}
