using System;

namespace SaveLoad
{
	[Serializable]
	public class DuplicatedHeroSerializable
	{
		public int index;

		public string id;
	}
}
